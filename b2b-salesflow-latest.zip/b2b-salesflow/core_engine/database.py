from typing import final as _final
from sqlite3 import connect as _connect
from logging import exception as _exception


class InformationCluster:
    def __init__(self, path: str) -> None:
        self.__path = path

    @property
    def path(self):
        return self.__path

    def getConnection(self):  # FIXME: Output type missing
        result = _connect(self.path)
        result.execute("PRAGMA foreign_keys = ON")
        return result


@_final
class FinanceCluster(InformationCluster):
    def __init__(self, path: str) -> None:
        super().__init__(path=path)

    def spinUp(self) -> None:
        connection = self.getConnection()
        cursor = connection.cursor()
        try:
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS Persons(
                    email TEXT NOT NULL PRIMARY KEY UNIQUE
                    ,   name TEXT NOT NULL
                    ,   lastName TEXT NOT NULL
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS Leads(
                    email TEXT NOT NULL PRIMARY KEY UNIQUE
                    ,   name TEXT NOT NULL
                    ,   lastName TEXT NOT NULL
                    ,   budget INTEGER CHECK(budget > 0)
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS Salesmen(
                    email TEXT NOT NULL PRIMARY KEY UNIQUE
                    ,   name TEXT NOT NULL
                    ,   lastName TEXT NOT NULL
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS Deals(
                    emailSalesman TEXT NOT NULL REFERENCES Salesmen(email)
                    ,   emailLead TEXT NOT NULL REFERENCES Leads(email)
                    ,   PRIMARY KEY (emailSalesman, emailLead)
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS Companies(
                    email TEXT NOT NULL PRIMARY KEY UNIQUE
                    ,   name TEXT NOT NULL UNIQUE
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS Teams(
                    emailCompany TEXT NOT NULL REFERENCES Companies(email)
                    ,   emailSalesman TEXT NOT NULL REFERENCES Salesmen(email)
                    ,   PRIMARY KEY (emailCompany, emailSalesman)
                )
            ''')
            connection.commit()
        except BaseException as e:
            _exception(e)
            connection.rollback()
        finally:
            connection.close()
