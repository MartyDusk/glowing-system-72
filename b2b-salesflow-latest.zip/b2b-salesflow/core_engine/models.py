from typing import final as _final
from copy import deepcopy as _deepcopy


class Person:
    def __init__(self, name: str, lastName: str, email: str) -> None:
        if len(name) < 2:
            # TODO: Are there names with less than two letters?
            # TODO: Not considering UTF-8 multi-grapheme glyphs
            raise Exception(
                f'Names must be at least 2 characters long | {name!r}'
            )
        if len(lastName) < 2:
            # TODO: Are there last names with less than two letters?
            # TODO: Not considering UTF-8 multi-grapheme glyphs
            raise Exception(
                f'Last names must be at least 2 characters long | {lastName!r}'
            )
        if not '@' in email:
            # TODO: Very basic check
            raise Exception(f'Invalid email | {email!r}')
        self.__name = name.title()
        self.__lastName = lastName.title()
        self.__email = email

    def __str__(self) -> str:
        return f'Person(name={self.name!r}, lastName={self.lastName!r}, email={self.email!r})'

    @property
    def name(self):
        return self.__name

    @property
    def lastName(self):
        return self.__lastName

    @property
    def email(self):
        return self.__email


@_final
class Lead(Person):
    def __init__(self, name: str, lastName: str, email: str, budget: int) -> None:
        if budget <= 0:
            raise Exception(f'Only positive budgets allowed | {budget!r}')
        super().__init__(
            name=name,
            lastName=lastName,
            email=email
        )
        self.__budget = budget

    def __str__(self) -> str:
        return f'Lead(name={self.name!r}, lastName={self.lastName!r}, email={self.email!r}, budget={self.budget!r})'

    def __eq__(self, value: object) -> bool:
        return isinstance(value, Lead) and self.email == value.email

    def __hash__(self) -> int:
        return hash((
            self.name,
            self.lastName,
            self.email,
            self.budget
        ))

    @property
    def budget(self):
        return self.__budget

    def isCorporate(self) -> bool:
        return all(map(lambda w: not self.email.endswith(w), ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com"]))

    def getPriority(self) -> None | bool:
        result = None
        if self.budget >= 10000:
            result = True
        elif self.budget >= 5000:
            result = False
        return result


@_final
class Salesman(Person):
    def __init__(self, name: str, lastName: str, email: str, clientPortfolio: None | list[Lead] = None) -> None:
        super().__init__(
            name=name,
            lastName=lastName,
            email=email
        )
        self.__clientPortfolio = [] if clientPortfolio is None else clientPortfolio

    def __str__(self) -> str:
        return f'Salesman(name={self.name}, lastName={self.lastName}, email={self.email}, id={self.getId()}, clientPortfolio=<{" + ".join(map(lambda x: str(x), self.__clientPortfolio))}>)'

    def __eq__(self, value: object) -> bool:
        return isinstance(value, Salesman) and (self.email == value.email)

    @property
    def clientPortfolio(self):
        copy = _deepcopy(self.__clientPortfolio)
        return copy

    def addPortfolio(self, lead: Lead) -> None:
        if lead in self.__clientPortfolio:
            raise Exception(f'Repeated lead | Lead : {lead.email}')
        else:
            self.__clientPortfolio.append(lead)

    def getId(self) -> int:
        return abs(hash(self.email))

    def getSalesPotential(self) -> int:
        return sum(map(lambda w: w.budget, self.__clientPortfolio))

    def getFeePotential(self) -> float:
        return ((5 * self.getSalesPotential()) / 100)


@_final
class Company(Person):
    def __init__(self, name: str, email: str, team: None | list[Salesman] = None) -> None:
        super().__init__(
            name=name,
            lastName='Inc.',
            email=email
        )
        self.__team = [] if team is None else team

    def __str__(self) -> str:
        return f'Company(name={self.name}, lastName={self.lastName}, email={self.email}, team=<{" + ".join(map(lambda x: str(x), self.__team))}>)'

    @property
    def team(self):
        copy = _deepcopy(self.__team)
        return copy

    def addTeam(self, salesman: Salesman) -> None:
        if salesman in self.__team:
            raise Exception(f'Repeated salesman | Salesman : {salesman.email}')
        else:
            self.__team.append(salesman)

    def getSalesPotential(self) -> int:
        return sum(map(lambda w: w.getSalesPotential(), self.__team))
