from logging import exception as _exception
from database import FinanceCluster as _FinanceCluster
from typing import Protocol as _Protocol, final as _final
from models import Person as _Person, Lead as _Lead, Salesman as _Salesman, Company as _Company


class IService[T](_Protocol):
    def save(self, obj: T) -> None: ...
    def everything(self) -> list[T]: ...

    def showAll(self) -> None:
        lazy = (print(x) for x in self.everything())

        def dummy(*_):
            pass
        dummy(*lazy)


@_final
class PersonsService(IService[_Person]):
    def __init__(self, financeCluster: _FinanceCluster) -> None:
        financeCluster.spinUp()
        self.__getConnection = financeCluster.getConnection

    def save(self, obj: _Person) -> None:
        connection = self.__getConnection()
        cursor = connection.cursor()
        try:
            cursor.execute(f'''
                INSERT INTO Persons(email, name, lastName)
                VALUES({','.join(3 * ['?'])})
            ''', (obj.email, obj.name, obj.lastName))
            connection.commit()
        except BaseException as e:
            _exception(e)
            connection.rollback()
        finally:
            connection.close()

    def everything(self) -> list[_Person]:
        result: list[_Person] = []
        connection = self.__getConnection()
        cursor = connection.cursor()
        try:
            cursor.execute('''
                SELECT email, name, lastName FROM Persons
            ''')
            for row in cursor.fetchall():
                email, name, lastName = row
                person = _Person(
                    email=email,
                    name=name,
                    lastName=lastName
                )
                result.append(person)
        except BaseException as e:
            _exception(e)
            connection.rollback()
        finally:
            connection.close()
        return result


@_final
class LeadsService(IService[_Lead]):
    def __init__(self, financeCluster: _FinanceCluster) -> None:
        financeCluster.spinUp()
        self.__getConnection = financeCluster.getConnection

    def save(self, obj: _Lead) -> None:
        connection = self.__getConnection()
        cursor = connection.cursor()
        try:
            cursor.execute(f'''
                INSERT INTO Leads(email, name, lastName, budget)
                VALUES({','.join(4 * ['?'])})
            ''', (obj.email, obj.name, obj.lastName, obj.budget))
            connection.commit()
        except BaseException as e:
            _exception(e)
            connection.rollback()
        finally:
            connection.close()

    def everything(self) -> list[_Lead]:
        result: list[_Lead] = []
        connection = self.__getConnection()
        cursor = connection.cursor()
        try:
            cursor.execute('''
                SELECT email, name, lastName, budget FROM Leads
            ''')
            for row in cursor.fetchall():
                email, name, lastName, budget = row
                lead = _Lead(
                    email=email,
                    name=name,
                    lastName=lastName,
                    budget=budget
                )
                result.append(lead)
        except BaseException as e:
            _exception(e)
            connection.rollback()
        finally:
            connection.close()
        return result


@_final
class SalesmenService(IService[_Salesman]):
    def __init__(self, financeCluster: _FinanceCluster) -> None:
        financeCluster.spinUp()
        self.__getConnection = financeCluster.getConnection

    def save(self, obj: _Salesman) -> None:
        self.saveSalesman(obj)
        self.saveDeals(obj)

    def saveSalesman(self, obj: _Salesman) -> None:
        connection = self.__getConnection()
        cursor = connection.cursor()
        try:
            cursor.execute(f'''
                INSERT INTO Salesmen(email, name, lastName)
                VALUES({','.join(3 * ['?'])})
            ''', (obj.email, obj.name, obj.lastName))
            connection.commit()
        except BaseException as e:
            _exception(e)
            connection.rollback()
        finally:
            connection.close()

    def saveDeals(self, obj: _Salesman) -> None:
        connection = self.__getConnection()
        cursor = connection.cursor()
        try:
            cursor.executemany(f'''
                INSERT INTO Deals(emailSalesman, emailLead)
                VALUES({','.join(2 * ['?'])})
            ''', ((obj.email, lead.email) for lead in obj.clientPortfolio))
            connection.commit()
        except BaseException as e:
            _exception(e)
            connection.rollback()
        finally:
            connection.close()

    def everything(self) -> list[_Salesman]:
        result: list[_Salesman] = []
        salesmen: dict[str, _Salesman] = {}
        connection = self.__getConnection()
        cursor = connection.cursor()
        try:
            cursor.execute('''
                SELECT
                    Salesmen.email
                ,   Salesmen.name
                ,   Salesmen.lastName
                ,   NULL
                ,   Leads.email
                ,   Leads.name
                ,   Leads.lastName
                ,   Leads.budget
                FROM Salesmen LEFT JOIN Deals
                    ON Salesmen.email = Deals.emailSalesman
                LEFT JOIN Leads
                    ON (Salesmen.email, Leads.email) = (Deals.emailSalesman, Deals.emailLead)
            ''')
            for row in cursor.fetchall():
                print(row)
                emailSalesman, nameSalesman, lastNameSalesman, _, emailLead, nameLead, lastNameLead, budgetLead = row
                if not emailSalesman in salesmen:
                    salesmen[emailSalesman] = _Salesman(
                        email=emailSalesman,
                        name=nameSalesman,
                        lastName=lastNameSalesman
                    )
                if not any(map(lambda w: w is None, (emailLead, nameLead, lastNameLead, budgetLead))):
                    lead = _Lead(
                        email=emailLead,
                        name=nameLead,
                        lastName=lastNameLead,
                        budget=budgetLead
                    )
                    salesmen[emailSalesman].addPortfolio(lead)
            return list(salesmen.values())
        except BaseException as e:
            _exception(e)
            connection.rollback()
        finally:
            connection.close()
        return result


class CompanyService(IService[_Company]):
    def __init__(self, financeCluster: _FinanceCluster) -> None:
        financeCluster.spinUp()
        self.__getConnection = financeCluster.getConnection

    def save(self, obj: _Company) -> None:
        self.saveCompany(obj)
        self.saveTeams(obj)

    def saveCompany(self, obj: _Company) -> None:
        connection = self.__getConnection()
        cursor = connection.cursor()
        try:
            cursor.execute(f'''
                INSERT INTO Companies(email, name)
                VALUES({','.join(2 * ['?'])})
            ''', (obj.email, obj.name))
            connection.commit()
        except BaseException as e:
            _exception(e)
            connection.rollback()
        finally:
            connection.close()

    def saveTeams(self, obj: _Company) -> None:
        connection = self.__getConnection()
        cursor = connection.cursor()
        try:
            cursor.executemany(f'''
                INSERT INTO Teams(emailCompany, emailSalesman)
                VALUES({','.join(2 * ['?'])})
            ''', ((obj.email, salesman.email) for salesman in obj.team))
            connection.commit()
        except BaseException as e:
            _exception(e)
            connection.rollback()
        finally:
            connection.close()

    def everything(self) -> list[_Company]:
        result: list[_Company] = []
        companies: dict[str, _Company] = {}
        salesmen: dict[str, _Salesman] = {}
        connection = self.__getConnection()
        cursor = connection.cursor()
        try:
            cursor.execute('''
                SELECT 
                    Companies.email, Companies.name, NULL
                ,   Salesmen.email, Salesmen.name, Salesmen.lastName, NULL
                ,   Leads.email, Leads.name, Leads.lastName, Leads.budget
                FROM Companies LEFT JOIN Teams
                    ON Companies.email = Teams.emailCompany
                LEFT JOIN Salesmen
                    ON (Companies.email, Salesmen.email) = (Teams.emailCompany, Teams.emailSalesman)
                LEFT JOIN Deals
                    ON Salesmen.email = Deals.emailSalesman
                LEFT JOIN Leads
                    ON (Salesmen.email, Leads.email) = (Deals.emailSalesman, Deals.emailLead)
            ''')
            for row in cursor.fetchall():
                emailCompany, nameCompany, _, emailSalesman, nameSalesman, lastNameSalesman, _, emailLead, nameLead, lastNameLead, budgetLead = row
                if not emailCompany in companies:
                    companies[emailCompany] = _Company(
                        email=emailCompany,
                        name=nameCompany
                    )
                if not any(map(lambda w: w is None, (emailSalesman, nameSalesman, lastNameSalesman))):
                    if not emailSalesman in salesmen:
                        salesmen[emailSalesman] = _Salesman(
                            email=emailSalesman,
                            name=nameSalesman,
                            lastName=lastNameSalesman
                        )
                        companies[emailCompany].addTeam(
                            salesmen[emailSalesman])
                    if not any(map(lambda w: w is None, (emailLead, nameLead, lastNameLead, budgetLead))):
                        lead = _Lead(
                            email=emailLead,
                            name=nameLead,
                            lastName=lastNameLead,
                            budget=budgetLead
                        )
                        salesmen[emailSalesman].addPortfolio(lead)
            return list(companies.values())
        except BaseException as e:
            _exception(e)
            connection.rollback()
        finally:
            connection.close()
        return result


if __name__ == '__main__':
    def dummy(*_):
        pass
    financeCluster = _FinanceCluster('finance.db')
    # leadsService = LeadsService(financeCluster)
    salesmenService = SalesmenService(financeCluster)
    companiesService = CompanyService(financeCluster)
    # leads = list(_Lead('Aa', 'Bb', f'@{i}', 10000) for i in range(5))
    # salesman = _Salesman("Ms.", "Saleswoman", "ms@saleswoman.com")
    # company = _Company('Monsters', 'admin@monsters.com')
    # dummy(*(salesman.addPortfolio(lead) for lead in leads))
    # company.addTeam(salesman)
    # dummy(*(leadsService.save(lead) for lead in leads))
    # salesmenService.save(salesman)
    # companiesService.save(company)
    # companiesService.showAll()
    a = _Salesman('Aa', 'Bb', '@0')
    b = _Salesman('Aa', 'Bb', '@0')
    c = [a, b]
    d = _Company('Aa', '@Bb', c)
    salesmenService.save(a)
    companiesService.save(d)
    print(d)
