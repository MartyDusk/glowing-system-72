import json

data = None

with open("users.json") as input:
    data = json.load(input)['leads']

with open("out.json", "w") as out:
    json.dump([{
        'city': x['address']['city'],
        'company': x['company']['name'],
        'email': x['email'],
        'name': x['name'],
        'zipcode': x['address']['zipcode']
    } for x in data], out)
        
        