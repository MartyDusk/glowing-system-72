import json

data = None

with open("users.json") as input:
    data = json.load(input)['leads']

with open("out2.json", "w") as out:
    json.dump([{
        'city': x['address']['city'],
        'lat': x['address']['geo']['lat'],
        'lng': x['address']['geo']['lng'],
        'name': x['name'],
        'phone': x['phone'],
        'website': x['website']
    } for x in data], out)
        
        