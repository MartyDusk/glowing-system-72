x = ["Carlos", "Ana", "Luis", "María"]

x.append("Raúl")
x.insert(0, "Rosa")
x.extend(["Wanda", "Paúl"])

print(f"{x=}")

[print(w) for w in x]
print()

y = sorted(x, reverse = True)

[print(w) for w in y]
print()

print(f"{y}")

print(f"""
Primeros tres elementos de la lista: {y[:3]}
Últimos tres elementos de la lista: {y[-3:]}
""")