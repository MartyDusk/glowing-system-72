w, v = (100000, 5/100)
calcular_com = lambda w, v: (w * v)

print(f"Comisión por venta de {w}: ${calcular_com(w, v)}")

leads = [
    {'Nombre': 'Empresa A', 'Presupuesto': 10000, 'Estado': 'Nuevo'},
    {'Nombre': 'Empresa B', 'Presupuesto': 15000, 'Estado': 'Contactado'},
    {'Nombre': 'Empresa C', 'Presupuesto': 12000, 'Estado': 'Cerrado'},
    {'Nombre': 'Empresa D', 'Presupuesto': 9000, 'Estado': 'Nuevo'}
]

leads_ordenados = sorted(leads, key = lambda w: w['Presupuesto'], reverse = True)
# [print(w) for w in leads_ordenados]

leads_mul = map(lambda w: (w['Presupuesto'] * 2), leads)
# [print(w) for w in leads_mul]

max = lambda x, y: x if x > y else y
# print(f"Máximo entre 10 y 20: {max(10, 20)}")

reverso = lambda x: x[::-1]
# print(f"Reverso de Hola -> {reverso("Hola")}")
# print(f"Reverso de Hola -> {"".join(reversed("Hola"))}")

suma = lambda *w: sum(w)
# print(f"Suma de 1, 2, 3 -> {suma(1, 2, 3)}")
# print(f"Suma de 10, 20, 30 -> {suma(10, 20, 30)}")
# print(f"Suma de 5, 10, 15 -> {suma(5, 10, 15)}")

mostrar_info = lambda **kwargs: print(f"Mostrar información recibida: {kwargs}")
mostrar_info(key1 = 'a', key2 = 'b')

evaluar = lambda w: 'Positivo' if w > 0 else 'Negativo' if w < 0 else 'Cero'
# print(evaluar(-5))
# print(evaluar(10))
# print(evaluar(0))

nombre_may = list(map(lambda w: w['Nombre'].upper(), leads))
# print(nombre_may)

inventario_crudo = [
    {"sku": "SKU-1001", "producto": "Teclado mecánico", "precio": "$49.99", "moneda": "USD"},
    {"sku": "SKU-1002", "producto": "Mouse inalámbrico", "precio": "$19.99", "moneda": "USD"},
    {"sku": "SKU-1003", "producto": "Monitor 24 pulgadas", "precio": "€129.90", "moneda": "EUR"},
    {"sku": "SKU-1004", "producto": "Auriculares Bluetooth", "precio": "$34.50", "moneda": "USD"},
    {"sku": "SKU-1005", "producto": "Webcam HD", "precio": "€27.75", "moneda": "EUR"}
]

TASA_EURO_A_USD = 1.08

def normalizar_producto(item: dict) -> dict:
    """
    Limpia el texto, convierte monedas, y formatea a un estándar
    """
    precio_limpio = float(item['precio'].replace("$", "").replace("€", ""))
    if item['moneda'] == 'EUR':
        precio_limpio = round(precio_limpio * TASA_EURO_A_USD, 2)
    return (lambda **x: x)(
        sku = item['sku'],
        producto = item['producto'].title(),
        precio_usd = precio_limpio
    )

inventario_limpio = list(map(normalizar_producto, inventario_crudo))

[print(f"{x['sku']} | {x['producto']} -> ${x['precio_usd']}") for x in inventario_limpio]