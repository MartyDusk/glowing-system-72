x = ('onboard', 'discarded', 'pending')
x += ('unknown',)

[print(w) for w in x]
print()

y = sorted(x, reverse = True)

[print(w) for w in y]
print()

print(f"""
Primeros tres elementos de la tupla: {y[:3]}
Últimos tres elementos de la tupla: {y[-3:]}
""")