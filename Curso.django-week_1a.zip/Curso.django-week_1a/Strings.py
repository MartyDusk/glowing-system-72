texto_sucio = "    Hola a todos    "

# print("Texto original: %s" % (texto_sucio,))
# print("Uso de lstrip: %s" % (texto_sucio.lstrip()))
# print("Uso de strip: %s" % (texto_sucio.rstrip()))
# print("Uso de strip: %s" % (texto_sucio.strip()))

saludo = "Hola gatos, adiós gatos"
# print("Texto original: %s" % (saludo,))
# print("Uso de replace: %s" % (saludo.replace('gatos', 'perros')))
# print("Uso de replace con count: %s" % (saludo.replace('gatos', 'perros', 1)))

csv = "manzana,pera,plátano,uva"
# print("Texto original: %s" % (csv,))

lista_frutas = csv.split(",");
# print("Lista de frutas: %s" % (lista_frutas))

conector = "-"
texto_unido = conector.join(lista_frutas)
# print("Texto unido: %s" % (texto_unido))

frase = "En un lugar de la Mancha, de cuyo nombre no quiero acordarme..."
# print("Uso de find(): %s" % (frase.find("lugar"),))
# print("Uso de count(): %d" % (frase.count("de"),))
# print("Uso de index(): %d" % (frase.index("Mancha"),))
# print("Uso de startswith(): %s" % (frase.startswith("En un lugar"),))
# print("Uso de endswith(): %s" % (frase.endswith("acordarme..."),))

# print("'12345'.isdigit()", '12345'.isdigit())
# print("'Hola'.isalpha()", 'Hola'.isalpha())
# print("'Hola mundo'.isalnum()", 'Hola mundo'.isalnum())
# print("'Hola mundo'.isspace()", 'Hola mundo'.isspace())
# print("'Hola mundo'.istitle()", 'Hola mundo'.istitle())
# print("'Hola mundo'.isupper()", 'Hola mundo'.isupper())
# print("'Hola mundo'.islower()", 'Hola mundo'.islower())

def procesar_datos(tabla: dict) -> list:
    """
    Función.

    Parámetros: tabla

    Retorna: lista
    """
    pass

# print(procesar_datos.__doc__)

STATUS = 'activo'
query_sql = f"""
SELECT id,usuario,nombre,fecha_registro
FROM usuarios
WHERE estado = '{STATUS}'
ORDER BY fecha_registro DESC;
"""

# print(f"Consulta SQL:\n{query_sql}")

ruta = r"C:\Windows\System32\nope"
# print(f"Ruta raw: {ruta}")

id_usuario = '45'
id_producto = '1642'
# print(f"ID Original: {id_usuario} -> ID Formateado {id_usuario.zfill(7)}")
# print(f"ID Original: {id_producto} -> ID Formateado {id_producto.zfill(7)}")

for x in range(1, 11):
    # print(f"Número original: {x} -> Número formateado: {str(x).zfill(3)}")
    pass

correo = "example@example.com"
usuario, arroba, dominio = correo.partition("@")

print(f"""
Correo original: {correo}
Usuario: {usuario}
Arroba: {arroba}
Dominio: {dominio}
""")

correo_falso = "usuario.dominio.com"
u = correo_falso.split("@")
print(f"{u}")