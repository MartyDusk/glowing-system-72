logs_servidor = [
    {"ip": "192.168.1.24", "requested_endpoint": "/api/v1/login", "http_status": 200, "user-agent": "Mozilla/5.0"},
    {"ip": "10.0.0.17", "requested_endpoint": "/api/v1/products", "http_status": 200, "user-agent": "Mozilla/5.0"},
    {"ip": "203.0.113.8", "requested_endpoint": "/admin/reset-all-passwords", "http_status": 403, "user-agent": "curl/8.1.2"},
    {"ip": "198.51.100.42", "requested_endpoint": "/.git/config", "http_status": 404, "user-agent": "sqlmap/1.7"},
    {"ip": "172.16.5.9", "requested_endpoint": "/api/v1/cart", "http_status": 200, "user-agent": "Mozilla/5.0"},
]

es_amenaza = lambda x: not any(map(lambda w: w.lower() in x['user-agent'].lower(), ['Chrome', 'Firefox', 'Mozilla']))
[print(x) for x in filter(es_amenaza, logs_servidor)]