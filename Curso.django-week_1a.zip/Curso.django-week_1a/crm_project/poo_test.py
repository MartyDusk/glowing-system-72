class Personaje:
    def __init__(self, nombre, salud_maxima):
        self.nombre = nombre
        self.salud_maxima = salud_maxima
        self._salud = salud_maxima
        self.inventario = ['Poción chica', 'Pan seco']
    @property
    def salud(self):
        return self._salud
    @salud.getter
    def salud(self, valor):
        resultado = None
        if valor < 0:
            resultado = 0
            print(f"Se murió")
        else:
            max = self.salud_maxima
            if valor > max:
                resultado = max
                print("Se healeo")
            else:
                resultado = valor
                print(f"Ahora tiene {valor} HP")
        self._salud = resultado
    @salud.deleter
    def salud(self):
        print("No se puede borrar")
    def _efecto_sonido_curacion(self):
        print("Glug-Glug")
    def tomar_pocion(self, valor):
        print(f"Regenerando {valor} HP")
        self._efecto_sonido_curacion()
        self.salud += valor
    def __str__(self):
        return f"Nombre: {self.nombre} | HP: {self.salud}/{self.salud_maxima}"
    def __repr__(self):
        return f"Personaje('{self.nombre}', {self.salud_maxima})"
    def __gt__(self, other):
        return self.salud_maxima > other.salud_maxima
    def __add__(self, other):
        nuevo_nombre = f"{self.nombre[3]}{other.nombre[3]}"
        nueva_salud = (self.salud_maxima + other.salud_maxima)
        return Personaje(nuevo_nombre, nueva_salud)
    def __len__(self):
        return len(self.inventario)
    @staticmethod
    def mostrar_manual_juego():
        print("¡Estático!")
    @classmethod
    def crear_npc_basico(cls):
        return cls("Aldeano genérico", 10)
    
class Guerrero(Personaje):
    def __init__(self, nombre, salud_maxima, puntos_armadura):
        super().__init__(nombre, salud_maxima)
        self.puntos_armadura = puntos_armadura
    def recibir_daño(self, daño):
        daño_real = daño - self.puntos_armadura
        if daño_real < 0:
            daño_real = 0
        self.salud -= daño_real
    def __str__(self):
        base = super().__str__()
        return f"{base} | Armadura: {self.puntos_armadura}"
    @classmethod
    def crear_espartano_elite(cls):
        return cls("Espartano", 200, 50)