class Person:
    def __init__(self, name: str, lastName: str, email: str) -> None:
        if len(name) < 2:
            # TODO: Are there names with just two letters?
            # TODO: Not considering UTF-8 multi-grapheme glyphs
            raise Exception(
                f"Names must be at least 2 characters long | {name!r}"
            )
        if len(lastName) < 2:
            # TODO: Not considering UTF-8 multi-grapheme glyphs
            raise Exception(
                f"Last names must be at least 2 characters long | {lastName!r}"
            )
        if not '@' in email:
            # TODO: Very basic check
            raise Exception(f"Invalid email | {email!r}")
        self.__name = name.title()
        self.__lastName = lastName.title()
        self.__email = email

    def __str__(self) -> str:
        return f"Person(name={self.name!r}, lastName={self.lastName!r}, email={self.email!r})"

    @property
    def name(self):
        return self.__name

    @property
    def lastName(self):
        return self.__lastName

    @property
    def email(self):
        return self.__email


class Lead(Person):
    def __init__(self, name: str, lastName: str, email: str, budget: int) -> None:
        if budget <= 0:
            raise Exception(f"Only positive budgets allowed | {budget!r}")
        super().__init__(
            name=name,
            lastName=lastName,
            email=email
        )
        self.__budget = budget

    def __str__(self) -> str:
        return f"Lead(name={self.name!r}, lastName={self.lastName!r}, email={self.email!r}, budget={self.budget!r})"

    def __eq__(self, value: object) -> bool:
        if not isinstance(value, Lead):
            return False
        else:
            return all((
                self.name == value.name,
                self.lastName == value.lastName,
                self.email == value.email,
                self.budget == value.budget
            ))

    def __hash__(self) -> int:
        return hash((
            self.name,
            self.lastName,
            self.email,
            self.budget
        ))

    @property
    def budget(self):
        return self.__budget

    def isCorporate(self) -> bool:
        return all(map(lambda w: not self.email.endswith(w), ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com"]))

    def getPriority(self) -> None | bool:
        result = None
        if self.budget >= 10000:
            result = True
        elif self.budget >= 5000:
            result = False
        return result


class Salesman(Person):
    def __init__(self, name: str, lastName: str, email: str, id: int, clientPortfolio: list[Lead]) -> None:
        if id < 0:
            raise Exception(f"Negative ID's disallowed | {id!r}")
        super().__init__(
            name=name,
            lastName=lastName,
            email=email
        )
        self.__id = id
        self.__clientPortfolio = clientPortfolio

    def __str__(self) -> str:
        return f"Salesman(name={self.name}, lastName={self.lastName}, email={self.email}, id={self.id}, clientPortfolio=<{" + ".join(map(lambda x: str(x), self.__clientPortfolio))}>)"

    @property
    def id(self):
        return self.__id

    @property
    def clientPortfolio(self):
        from copy import deepcopy
        copy = deepcopy(self.__clientPortfolio)
        return copy

    def addPortfolio(self, lead: Lead) -> None:
        if lead in self.__clientPortfolio:
            raise Exception(f"Repeated lead | Lead : {lead}")
        else:
            self.__clientPortfolio.append(lead)

    def salesPotential(self) -> int:
        return sum(map(lambda w: w.budget, self.__clientPortfolio))

    def feePotential(self) -> float:
        return ((5 * self.salesPotential()) / 100)


class Company(Person):
    def __init__(self, name: str, email: str, team: list[Salesman]) -> None:
        super().__init__(
            name=name,
            lastName='Inc.',
            email=email
        )
        self.__team = team

    def __str__(self) -> str:
        return f"Company(name={self.name}, lastName={self.lastName}, email={self.email}, team=<{" + ".join(map(lambda x: str(x), self.__team))}>)"

    @property
    def team(self):
        from copy import deepcopy
        copy = deepcopy(self.__team)
        return copy

    def addTeam(self, salesman: Salesman) -> None:
        self.__team.append(salesman)

    def salesPotential(self) -> int:
        return sum(map(lambda w: w.salesPotential(), self.__team))
