from core_engine.models import Person
from models import *
from database import FinanceCluster
from abc import ABC, abstractmethod


class IRepository[T](ABC):
    @abstractmethod
    def save(self, obj: T) -> None:
        raise TypeError()

    @abstractmethod
    def everything(self) -> list[T]:
        raise TypeError()


class IService[T](ABC):
    def __init__(self, repository: IRepository[T]) -> None:
        self.__repository = repository

    @abstractmethod
    def register(self, obj: T) -> None:
        raise TypeError()

    def showAll(self) -> None:
        lazy = (print(x) for x in self.__repository.everything())

        def dummy(*_):
            pass
        dummy(*lazy)


class PersonsRepository(IRepository[Person]):
    def __init__(self, financeCluster: FinanceCluster) -> None:
        financeCluster.spinUp()
        self.__getConnection = financeCluster.getConnection

    def save(self, obj: Person) -> None:
        connection = self.__getConnection()
        cursor = connection.cursor()
        try:
            cursor.execute('''
                INSERT INTO Persons(email, name, lastName)
                VALUES(?, ?, ?)
            ''', (obj.email, obj.name, obj.lastName))
            connection.commit()
        except:
            connection.rollback()
        finally:
            connection.close()

    def everything(self) -> list[Person]:
        result: list[Person] = []
        connection = self.__getConnection()
        cursor = connection.cursor()
        try:
            cursor.execute('''
                SELECT email, name, lastName from Persons
            ''')
            for row in cursor.fetchall():
                email, name, lastName = row
                person = Person(
                    email=email,
                    name=name,
                    lastName=lastName
                )
                result.append(person)
        except:
            connection.rollback()
        finally:
            connection.close()
        return result


class PersonsService(IService[Person]):
    def __init__(self, repository: IRepository[Person]) -> None:
        super().__init__(repository)

    def register(self, obj: Person) -> None:
        se


if __name__ == '__main__':
    financeCluster = FinanceCluster('finance.db')
    repository = PersonsRepository(financeCluster)
