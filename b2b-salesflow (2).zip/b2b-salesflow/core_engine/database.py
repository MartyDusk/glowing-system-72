class InformationCluster:
    def __init__(self, path: str) -> None:
        self.__path = path

    @property
    def path(self):
        return self.__path

    def getConnection(self):  # FIXME: Output type missing
        from sqlite3 import connect
        result = connect(self.path)
        result.execute("PRAGMA foreign_keys = ON")
        return result


class FinanceCluster(InformationCluster):
    def __init__(self, path: str) -> None:
        super().__init__(path=path)

    def spinUp(self) -> None:
        connection = self.getConnection()
        cursor = connection.cursor()
        try:
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS Persons(
                    email TEXT NOT NULL PRIMARY KEY UNIQUE
                    ,   name TEXT NOT NULL
                    ,   lastName TEXT NOT NULL
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS Leads(
                    email TEXT NOT NULL PRIMARY KEY UNIQUE
                    ,   name TEXT NOT NULL
                    ,   lastName TEXT NOT NULL
                    ,   budget INTEGER CHECK(budget > 0)
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS Salesmen(
                    email TEXT NOT NULL PRIMARY KEY UNIQUE
                    ,   name TEXT NOT NULL
                    ,   lastName TEXT NOT NULL
                    ,   id INTEGER UNIQUE
                    ,   clientPortfolio TEXT NOT NULL
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS Companies(
                    email TEXT NOT NULL PRIMARY KEY UNIQUE
                    ,   name TEXT NOT NULL UNIQUE
                    ,   team TEXT NOT NULL 
                )
            ''')
            connection.commit()
        except:
            connection.rollback()
        finally:
            connection.close()
